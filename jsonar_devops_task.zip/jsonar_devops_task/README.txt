jSonar DevOps task by Jeremy Reid

email me at jeremy_r@telus.net if you have any questions or concerns

Accounts and Passwords:
AWS:
My account number to log into AWS is:
118748109360

Account: jSonar
Password: jSonar1234

MongoDB:
Account: admin
Password: admin

MongoDB express:
Account: admin
Password: admin

MariaDB:
Account: admin
Password: admin1234

jSonarClient - ec2-18-236-77-53.us-west-2.compute.amazonaws.com
jSonarServer - ec2-52-34-116-1.us-west-2.compute.amazonaws.com

MongoDB express - ec2-52-34-116-1.us-west-2.compute.amazonaws.com:8081/db/jSonar/

Phase 1 was achieved by running the script jSonar.sh

I used a Git bash shell for running this script, it uses my AWS account, using my admin credentials.
These are the steps it performs to fully automat the phase 1 tasks:
	1. It creates the jSonar AWS user using my AWS account.  The user has read priviledges for most
	   AWS tasks, but has admin rights for RDS, so it can create the Maria DB in phase 2
	2. Create a new keypair jSonar.pem for logging in EC2 instances.  I commented out after it was
	   run as the only manual step I had to do, which is beyond the scope of the task is to use
	   puttygen on jSonar.pem to create jSonar.ppk so that I could log into EC2 instances using
	   jSonar.pem
	3. Create credentials for jSonar user so that it can run aws cli on EC2 instances
	4. Create security group with open SSH and ICMP so anybody can reach EC2 instances
	5. Create 2 EC2 instances based on Ubuntu 18.04 images, and name them jSonarServer and jSonarClient
        6. Install Docker on EC2 instances
	7. Install MongoDB on server using Docker container.  I used the included docker-compose.yml for
	   the creation of the MongoDB server container
	8. On the client install MongoDB client
	9. Install AWS cli on both EC2 instances and configure credentials generated in step 3
	10. On the client connect MongoDB client to the server, and run included helloworld.js
	11. Prep client for running phase2.py python script by installing required tools, then starting
	    the python script

Phase 2 was achieved by running the python script phase2.py
       1. Create MariaDB using aws cli
       2. Run describe-db-instances on the client twice, and each time insert into MongoDB
       3. Query for running RDS servers by checking if available, should be 2 since we checked 
          describe-db-instances twice after a clean install
       4. Delete one of the inserted documents, and should be left with one still in MongoDB

Include files:
ak.txt                 - generated file for storing credentials
docker-compose.yml     - used to generate MongoDB container
helloworld.js          - javascript commands for automation of Mongo shell client
jSonar DevOps task.pdf - description of my task
jSonar.log             - log of whole process of the DevOps task.  Sorry it will be tough to read in places 
                         at it is just collected from stderr and stdout of the run of jSonar.sh
jSonar.pem             - keypair file
jSonar.ppk             - manually generated file so that I could log into EC2 instances using putty
jSonar.sh              - bash script that drove the whole process.  Only step that needs to be be done manually
                         (other than to use putty)
jSonar-policy.json     - file used to set IAM permissions for jSonar user
phase2.py              - python script used to perform phase 2 steps
README.txt             - this file

