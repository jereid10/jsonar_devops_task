import subprocess
import time
import json
from pymongo import MongoClient
from pymongo import collection

def create_mariadb():
    cmd="aws rds create-db-instance --db-name jSonarMariaDB \
        --db-instance-identifier jSonarMariaDB \
        --db-instance-class db.m4.large \
        --engine MariaDB --allocated-storage 20 \
        --master-username admin --master-user-password admin1234"
    push=subprocess.Popen(cmd, shell=True, stdout = subprocess.PIPE)
    print push.returncode
    print "create_mariadb completed, waiting 10 minutes for it to initialize"
    time.sleep(600) 

def get_db_instances():
    # get describe-db-instances content to be used later 
    cmd="aws rds describe-db-instances"
    push=subprocess.Popen(cmd, shell=True, stdout = subprocess.PIPE)
    push.wait()
    return push.stdout


def mongoDB_tasks(address):
    client = MongoClient(address)
    db=client.jSonar
    mycol = db["RDS"]

    # take output of describe-db-instances of MariaDB and insert
    # into RDS collection on MongoDB 2 times, since one will be
    # deleted.  Keep on there for future reference
    for i in range(2):
        ddb = get_db_instances()
        print "Inserting output of describe-db-instances into Mongodb"
        ddb_data = json.load(ddb)
        print ddb.read()
        mycol.insert_one(ddb_data)

    # now query running instances avaible status 
    print "Looking for available DBS stored in Mongodb, in RDS collection"
    answer = mycol.find({"DBInstances.DBInstanceStatus": "available"}, {"DBInstances.DBName": 1, "DBInstances.Engine": 1})
    print answer
    # grab the last 
    count = 0
    for x in answer:
        count += 1
        print x
        dbname = x["DBInstances"][0]["DBName"]
    print "There are currently ", count, "avaiable DBInstances in collection"
    dbname = dbname.encode("ascii")
    print "Print deleting one document containing DBName ", dbname 
    # now delete one of the returned answers
    mycol.delete_one({"DBInstances.DBName" : dbname})

ddb = create_mariadb()
mongoDB_tasks("mongodb://admin:admin@REPLACE_ME:27017/admin")
