#!/bin/bash

# Ubuntu Server 18.04 LTS (HVM), SSD Volume Type - ami-003634241a8fcdec0
AMI="ami-003634241a8fcdec0"
# Using my already created key pair
KEY_NAME='jSonar'
USER='jSonar'
SERVER_NAME="${USER}Server"
CLIENT_NAME="${USER}Client"
SECURITY_GROUP_NAME="${USER}Task"

# currently not using
AZ="us-west-2b"

function create_user {
    echo "Creating user $USER in AWS"
    aws iam create-user --user-name $USER
    aws iam create-login-profile --user-name $USER --password "${USER}1234"
    POLICY=$(aws iam create-policy --policy-name jSonar-policy --policy-document file://jSonar-policy.json | \
        grep 'Arn' | awk -F '"' '{print $4}')
    aws iam attach-user-policy --user-name $USER --policy-arn $POLICY
    aws iam list-attached-user-policies --user-name $USER

}

function create_keypair {
   echo "Creating keypair to used by the script"
   # delete just in case it already exists
   aws ec2 delete-key-pair --key-name $KEY_NAME
   aws ec2 create-key-pair --key-name $KEY_NAME --query 'KeyMaterial' --output text > $KEY_NAME.pem
   chmod 400 $KEY_NAME.pem
}

function create_access_key {
   echo "Creating access and secret key for $USER"
   aws iam create-access-key --user-name $USER > ak.txt
   AK=$(cat ak.txt | grep AccessKeyId | awk -F '"' '{print $4}')
   SK=$(cat ak.txt | grep SecretAccessKey | awk -F '"' '{print $4}')
   echo $AK > credentials
   echo $SK >> credentials
}

function create_security_group {
    # create security group that allows ssh and ping from anywhere
    echo "Creating security group $SECURITY_GROUP_NAME"
    SG=$(aws ec2 create-security-group --group-name $SECURITY_GROUP_NAME \
       --description "Create a security group specifically for my development task" | \
       grep GroupId | awk -F '"' '{print $4}')
    aws ec2 authorize-security-group-ingress --group-name $SECURITY_GROUP_NAME \
        --protocol tcp --cidr 0.0.0.0/0 --port 0-65535
    aws ec2 authorize-security-group-ingress --group-name $SECURITY_GROUP_NAME \
        --protocol icmp --cidr 0.0.0.0/0 --port all
}

function create_ec2 {
       EC2_NAME=$1
       echo "Creating EC2 instance for $EC2_NAME"
       EC=$(aws ec2 run-instances --image-id $AMI --count 1 --instance-type t2.micro --key-name $KEY_NAME \
          --security-group-ids $SG --subnet-id subnet-0d7e8d75 | \
          grep InstanceId | awk -F '"' '{print $4}')
       echo "Tagging $EC $EC2_NAME"
       aws ec2 create-tags  --resources $EC --tag "Key=Name,Value=$EC2_NAME"
}

 function get_dns_name {
   EC2_ID=$1   
   DNS_NAME=$(aws ec2 describe-instances --instance-ids $EC2_ID | grep -m 1 PublicDnsName | awk -F '"' '{print $4}')
}

function install_docker {
    EC2_DNS_NAME=$1
    echo "Installing docker on $EC2_DNS_NAME"
    ssh -o StrictHostKeyChecking=no -i "$KEY_NAME.pem" ubuntu@$EC2_DNS_NAME \
        'sudo apt-get update && sudo apt-get -y install docker.io && \
	sudo apt-get -y install docker-compose && sudo usermod -aG docker ${USER} && exit'
}   

function install_mongodb {
    EC2_DNS_NAME=$1
    HOST_TYPE=$2
    if [[ "$HOST_TYPE" == "server" ]]; then
        echo "Installing mongo server on $EC2_DNS_NAME"
	scp -i "$KEY_NAME.pem" init-mongo.js ubuntu@$EC2_DNS_NAME:
	scp -i "$KEY_NAME.pem" docker-compose.yml ubuntu@$EC2_DNS_NAME:
        COMMAND="mkdir mongo-volume && docker-compose up -d && exit"
    else
        echo "Installing mongo client on $EC2_DNS_NAME"
	COMMAND="sudo apt-get -y install mongodb-clients && exit"
    fi
    ssh -o StrictHostKeyChecking=no -i "$KEY_NAME.pem" ubuntu@$EC2_DNS_NAME "$COMMAND"
}

function insert_into_mongodb {
    echo "Creating helloworld document from $CLIENT_DNS_NAME to $SERVER_DNS_NAME"
    sed "s/REPLACE_ME/$SERVER_DNS_NAME/g" helloworld.js > helloworld.js.tmp
    scp -i "$KEY_NAME.pem" helloworld.js.tmp ubuntu@$CLIENT_DNS_NAME:helloworld.js
    rm helloworld.js.tmp
    ssh -o StrictHostKeyChecking=no -i "$KEY_NAME.pem" ubuntu@$CLIENT_DNS_NAME \
        "mongo mongodb://admin:admin@$SERVER_DNS_NAME:27017/admin < helloworld.js"
}

function install_aws_cli {
    EC2_DNS_NAME=$1
    echo "Installing aws cli on $EC2_DNS_NAME"
    ssh -o StrictHostKeyChecking=no -i "$KEY_NAME.pem" ubuntu@$EC2_DNS_NAME 'curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" \
    -o "awscliv2.zip" && sudo apt-get -y install unzip && unzip awscliv2.zip && sudo ./aws/install && mkdir ~/.aws && exit'
    scp -i "$KEY_NAME.pem" credentials ubuntu@$EC2_DNS_NAME:.aws
}

function trigger_phase2 {
    
    echo "Starting phase 2 of assignment on $CLIENT_DNS_NAME"
    sed "s/REPLACE_ME/$SERVER_DNS_NAME/g" phase2.py > phase2.py.tmp
    scp -i "$KEY_NAME.pem" phase2.py.tmp ubuntu@$CLIENT_DNS_NAME:phase2.py
    rm phase2.py.tmp
    ssh -o StrictHostKeyChecking=no -i "$KEY_NAME.pem" ubuntu@$CLIENT_DNS_NAME 'sudo apt-get install -y python-pip && \
        python -m pip install pymongo && python ./phase2.py'
}

create_user
create_keypair
create_access_key
create_security_group
echo "Using security group $SG"
create_ec2 $SERVER_NAME 
SERVER_ID=$EC
create_ec2 $CLIENT_NAME
CLIENT_ID=$EC
get_dns_name $SERVER_ID
SERVER_DNS_NAME=$DNS_NAME
get_dns_name $CLIENT_ID
CLIENT_DNS_NAME=$DNS_NAME
echo "Need to wait for EC2 instances to boot"
sleep 60
install_docker $SERVER_DNS_NAME
install_docker $CLIENT_DNS_NAME
install_mongodb $SERVER_DNS_NAME server
install_mongodb $CLIENT_DNS_NAME client
install_aws_cli $SERVER_DNS_NAME
install_aws_cli $CLIENT_DNS_NAME
insert_into_mongodb
trigger_phase2

