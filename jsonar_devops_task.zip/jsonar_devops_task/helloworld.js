db = connect("mongodb://admin:admin@REPLACE_ME:27017/admin");
db = db.getSiblingDB('jSonar');
db.createCollection('HelloWorld');
db.HelloWorld.insert( { 'First Name' : 'Jeremy', 'Last Name' : 'Reid' });



